import * as nFunctions from "./modules/functions.js";
//nFunctions.nCustomCursor();
//nFunctions.nWhatAscreen();
//nFunctions.nHeader();
//nFunctions.isWebp();
nFunctions.dynamicAdapt();
//nFunctions.nLazyLoading();
//nFunctions.nSelect();
nFunctions.nSpollers();

document.addEventListener('DOMContentLoaded', function() {
   
   // Same height for .how-agro-took-works__item
   function setEqualHeight() {
      const boxes = document.querySelectorAll('.how-agro-took-works__item');
      
      if (window.innerWidth >= 801) {
         if (boxes.length > 0) {
            boxes.forEach(box => box.style.height = 'auto');

            let height = 0;
            boxes.forEach(box => {
               const currentHeight = box.offsetHeight;
               if (currentHeight > height) {
                  height = currentHeight;
               }
            });
            boxes.forEach(box => {
               box.style.height = `${height}px`;
            });
         }
      } else {
         boxes.forEach(box => box.style.height = 'auto');
      }
   }
   setEqualHeight();
   window.addEventListener('resize', setEqualHeight);
   window.addEventListener('orientationchange', setEqualHeight);

   // Buttons fo favorites
   let topProductsFavoritesButtons = document.querySelectorAll('.top-products__favorites-btn');
   if (topProductsFavoritesButtons) {
      topProductsFavoritesButtons.forEach((topProductsFavoritesButton) => {
         topProductsFavoritesButton.addEventListener('click', (events) => {
            events.preventDefault();
         });
      })
   }

   // Opening and selecting a Categories
   let headerCategoriesSelect = document.querySelector('.header__categories-select');
   if (headerCategoriesSelect) {
      headerCategoriesSelect.addEventListener('click', () => {
         headerCategoriesSelect.classList.toggle('open');
         if (window.matchMedia("(max-width: 720px)").matches) {
            document.body.classList.toggle('_lock');
         }
      });
   }

   // Opening and selecting a language
   const LangSelectCurrent = document.querySelector('.header__lang-select-current-icon');
   const headerLangSelectIcon = document.querySelector('.header__lang-select-current-icon img');
   const langLinks = document.querySelectorAll('.block-langs ul li a');
   const headerLangSelect = document.querySelector('.header__lang-select');

   // Universal language change logic (for all devices)
   if (headerLangSelectIcon && langLinks.length) {
      langLinks.forEach(link => {
         link.addEventListener('click', () => {
            // Remove the `current-lang` class from all elements
            langLinks.forEach(lang => {
               lang.parentElement.classList.remove('current-lang');
            });

            // Add `current-lang` to the current element
            const parentLi = link.parentElement;
            parentLi.classList.add('current-lang');

            // Replace the image and alt text
            const img = link.querySelector('img');
            if (img) {
               headerLangSelectIcon.src = img.src;
               headerLangSelectIcon.alt = img.alt;
            }
            if (headerLangSelect) { // Close the menu after selecting the language
               headerLangSelect.classList.remove('open');
            }
         });
      });
   }
   if ('ontouchstart' in window) { // Logic for adding/removing `open` class
      if (LangSelectCurrent) { // For touch devices - on click
         LangSelectCurrent.addEventListener('click', () => {
            headerLangSelect.classList.toggle('open');
         });
      }
   } else {
      if (headerLangSelect) { // For devices with a mouse - on hover
         headerLangSelect.addEventListener('mouseenter', () => {
            headerLangSelect.classList.add('open');
         });
         headerLangSelect.addEventListener('mouseleave', () => {
            headerLangSelect.classList.remove('open');
         });
      }
      if (LangSelectCurrent) { // Click on the icon - open/close
         LangSelectCurrent.addEventListener('click', () => {
            headerLangSelect.classList.toggle('open');
         });
      }
   }

   // User links (Header)
   let openListUsers = document.querySelectorAll('.open-list-user');
   const userLinks = document.querySelectorAll('.header__blockProfileLinks ul li a');
   if (openListUsers) {
      openListUsers.forEach((openListUser) => {
         openListUser.addEventListener('click', (event) => {
            event.preventDefault();
            openListUser.parentNode.classList.toggle('open');
         });
      })
      userLinks.forEach((userLink) => {
         userLink.addEventListener('click', () => {
            document.querySelector('.header__blockProfile').classList.toggle('open');
         });
      })
   }

   // Agro Took Service buttons (Tabs)
   var parentTabs = document.querySelectorAll('.agro-took-service__buttons .agro-took-service__button');
   if (parentTabs) {
      parentTabs.forEach(function (parentTab) {
         parentTab.addEventListener('click', function () {
            var parentTabId = this.getAttribute('data-tab');
            var correspondingParentTabContent = document.querySelector('.agro-took-service__block[data-tabcontent="' + parentTabId + '"]');
            document.querySelectorAll('.agro-took-service__buttons .agro-took-service__button').forEach(function (tab) {
               tab.classList.remove('active');
            });
            document.querySelectorAll('.agro-took-service__block').forEach(function (content) {
               content.classList.remove('content-active');
            });
            this.classList.add('active');
            correspondingParentTabContent.classList.add('content-active');
         });
      });
   }

   // Active Radio buttons in filter
   document.querySelectorAll('.block-sort-by').forEach(blockSortBy => {
      const blockSortByButtons = blockSortBy.querySelectorAll('.block-sort-by__button');
      const applyButton = blockSortBy.querySelector('.block-sort-by__apply');
      const inputs = blockSortBy.querySelectorAll('input:not([type="radio"])'); // Exclude radio
      const radioInputs = blockSortBy.querySelectorAll('input[type="radio"]');
      const hiddenInputs = blockSortBy.querySelectorAll('input[type="hidden"]'); // Separately for hidden
      const selectElements = blockSortBy.querySelectorAll('select');
   
      if (applyButton) {
         const updateApplyButtonVisibility = () => {
            // Check for active buttons
            const hasActiveButton = Array.from(blockSortByButtons).some(button =>
               button.classList.contains('active')
            );
   
            // Check for filled input (except radio)
            const hasFilledInput = Array.from(inputs).some(input => input.value.trim() !== '');
   
            // Checking filled hidden fields
            const hasFilledHiddenInput = Array.from(hiddenInputs).some(input => input.value.trim() !== '');
   
            // Checking select elements (excluding selected disabled)
            const hasValidSelect = Array.from(selectElements).some(select => {
               return select.value && !select.querySelector('option:disabled[selected]');
            });
   
            // Checking active radio buttons (checked only)
            const hasCheckedRadio = Array.from(radioInputs).some(input => input.checked);
   
            // Condition for displaying the button
            if (hasCheckedRadio || hasFilledInput || hasFilledHiddenInput || hasValidSelect || hasActiveButton) {
               applyButton.classList.add('show');
            } else {
               applyButton.classList.remove('show');
            }
         };
   
         // Event listeners
         blockSortByButtons.forEach(button => {
            button.addEventListener('click', () => {
               button.classList.toggle('active');
               updateApplyButtonVisibility();
            });
         });
   
         inputs.forEach(input => {
            input.addEventListener('input', updateApplyButtonVisibility);
         });
   
         hiddenInputs.forEach(input => {
            // Subscribe to changes via MutationObserver
            const observer = new MutationObserver(updateApplyButtonVisibility);
            observer.observe(input, { attributes: true, attributeFilter: ['value'] });
         });
   
         radioInputs.forEach(input => {
            input.addEventListener('change', updateApplyButtonVisibility);
         });
   
         selectElements.forEach(select => {
            select.addEventListener('change', updateApplyButtonVisibility);
         });
   
         // Initialization
         updateApplyButtonVisibility();
      }
   });

   // show-sidebar
   const showSidebar = document.getElementById('show-sidebar');
   if (showSidebar) {
      showSidebar.addEventListener('click', () => {
         document.getElementById('sidebar-sort-by').classList.toggle('show');
         document.body.classList.toggle('_lock');
      });
   }

   // Block advertisement checked
   const advertisementItems = document.querySelectorAll('.advertisement__item');
   if (advertisementItems.length > 0) {
      advertisementItems.forEach(item => {
         const button = item.querySelector('.advertisement__button');
         if (button) {
            button.addEventListener('click', (e) => {
            e.preventDefault();
               if (item.classList.contains('checked')) {
                  item.classList.remove('checked');
               } else {
                  advertisementItems.forEach(otherItem => {
                     otherItem.classList.remove('checked');
                  });
                  item.classList.add('checked');
               }
            });
         }
      });
   }

   // Widget button
   let showWidgetInfo = document.getElementById('show-widget-info');
   if (showWidgetInfo) {
      showWidgetInfo.addEventListener('click', () => {
         showWidgetInfo.parentNode.classList.toggle('open');
      });
   }
});

nFunctions.nPopUp();
//nFunctions.backToTop();